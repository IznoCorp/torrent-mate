// KanbanMate config — Defaults, Validation, and YAML preview panels.
const KMS = window.KanbanMateDesignSystem_2463ad;

// ---- Defaults: board-wide concurrency_cap + move_rate_limit_per_hour ----
function DefaultsPanel() {
  const data = window.KMConfigData;
  const { Card, Input, Banner, KeyChip } = KMS;
  const [cc, setCc] = React.useState(data.defaults.concurrency_cap);
  const [rl, setRl] = React.useState(data.defaults.move_rate_limit_per_hour);
  return (
    <div style={{ maxWidth: 620, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 16 }}>
      <Banner tone="neutral">Board-wide pipeline defaults from the <KeyChip>transitions.yml</KeyChip> <KeyChip>defaults:</KeyChip> block. The daemon and agents always run non-root.</Banner>
      <Card padding="none">
        <SettingRow label="concurrency_cap" hint="Maximum concurrent agent sessions across the whole project.">
          <Input type="number" value={cc} onChange={(e) => setCc(e.target.value)} mono style={{ width: 88 }} />
        </SettingRow>
        <div style={{ height: 1, background: 'var(--border)' }} />
        <SettingRow label="move_rate_limit_per_hour" hint="Per-item AUTO / bot move rate limit per hour.">
          <Input type="number" value={rl} onChange={(e) => setRl(e.target.value)} mono style={{ width: 88 }} />
        </SettingRow>
      </Card>
    </div>
  );
}

function SettingRow({ label, hint, children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '14px 18px' }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)', fontWeight: 600, color: 'var(--foreground)' }}>{label}</div>
        <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 3, lineHeight: 1.45 }}>{hint}</div>
      </div>
      {children}
    </div>
  );
}

// ---- Validation: V1–V10 findings; errors block save, warnings advisory ----
function ValidationPanel({ findings = [], onGoto }) {
  const { FindingItem, Banner } = KMS;
  const errs = findings.filter((f) => f.severity === 'error');
  const warns = findings.filter((f) => f.severity === 'warning');
  return (
    <div style={{ maxWidth: 760, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 14 }}>
      {errs.length > 0
        ? <Banner tone="error" title={`${errs.length} error${errs.length > 1 ? 's' : ''} block save`}>Fix the located fields below — nothing is written until they pass.</Banner>
        : <Banner tone="success" title="Config is valid">All semantic checks pass. Save writes columns.yml + transitions.yml.</Banner>}
      {warns.length > 0 && <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '.06em', textTransform: 'uppercase', color: 'var(--muted-foreground)', marginTop: 4 }}>{warns.length} advisory warning{warns.length > 1 ? 's' : ''}</div>}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {findings.map((f, i) => <FindingItem key={i} severity={f.severity} field={f.field} message={f.message} onClick={() => onGoto && onGoto(f.field)} />)}
      </div>
    </div>
  );
}

// ---- YAML preview: read-only render of the two config files ----
function YamlPanel() {
  const data = window.KMConfigData;
  const { SegmentedControl } = KMS;
  const [file, setFile] = React.useState('transitions.yml');

  const transitions = [
    `project: ${data.binding.project}`, '',
    'defaults:',
    `  concurrency_cap: ${data.defaults.concurrency_cap}`,
    `  move_rate_limit_per_hour: ${data.defaults.move_rate_limit_per_hour}`,
    '', 'transitions:',
    ...data.transitions.flatMap((t) => {
      const from = Array.isArray(t.from) ? `[${t.from.join(', ')}]` : t.from;
      const lines = [`  - from: ${from}`, `    to: ${t.to}`];
      if (t.profile) lines.push(`    profile: ${t.profile}`);
      if (t.prompt) lines.push(`    prompt: ${t.prompt}`);
      if (t.script) lines.push(`    script: ${t.script}`);
      lines.push(`    advance: ${t.advance}`);
      lines.push(`    permission_mode: ${t.permission_mode}`);
      return [...lines, ''];
    }),
  ];
  const columns = ['columns:', ...data.columns.flatMap((c) => {
    const lines = [`  - key: ${c.key}`, `    name: ${c.name}`];
    if (c.cls === 'agent') { lines.push('    triggers_agent: true'); if (c.prompt) lines.push(`    prompt: ${c.prompt}`); if (c.profile) lines.push(`    permission_profile: ${c.profile}`); }
    if (c.cls === 'reactive') lines.push('    action: teardown');
    return [...lines, ''];
  })];

  const lines = file === 'transitions.yml' ? transitions : columns;
  return (
    <div style={{ maxWidth: 760, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 14 }}>
      <SegmentedControl mono options={['transitions.yml', 'columns.yml']} value={file} onChange={setFile} />
      <div style={{ background: 'var(--surface-inverse)', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '9px 14px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <span style={{ width: 9, height: 9, borderRadius: '50%', background: '#e0494e' }} />
          <span style={{ width: 9, height: 9, borderRadius: '50%', background: '#d98e29' }} />
          <span style={{ width: 9, height: 9, borderRadius: '50%', background: '#1f9d54' }} />
          <span style={{ marginLeft: 8, fontFamily: 'var(--font-mono)', fontSize: 11, color: 'rgba(255,255,255,0.55)' }}>.claude/kanban/{file}</span>
        </div>
        <pre style={{ margin: 0, padding: '14px 18px', fontFamily: 'var(--font-mono)', fontSize: 12.5, lineHeight: 1.65, color: '#e2e2d6', overflow: 'auto', maxHeight: 460 }}>{lines.map((l, i) => (
          <div key={i}><span style={{ display: 'inline-block', width: 26, color: 'rgba(255,255,255,0.28)', userSelect: 'none' }}>{l ? i + 1 : ''}</span><span dangerouslySetInnerHTML={{ __html: highlight(l) }} /></div>
        ))}</pre>
      </div>
    </div>
  );
}

function highlight(line) {
  const esc = line.replace(/&/g, '&amp;').replace(/</g, '&lt;');
  return esc
    .replace(/^(\s*-?\s*)([a-z_]+)(:)/, '$1<span style="color:#6cd097">$2</span><span style="color:rgba(255,255,255,0.4)">$3</span>')
    .replace(/(triggers_agent|action): (true|teardown)/, '<span style="color:#6cd097">$1</span><span style="color:rgba(255,255,255,0.4)">:</span> <span style="color:#b6a3e6">$2</span>');
}

Object.assign(window, { DefaultsPanel, ValidationPanel, YamlPanel });

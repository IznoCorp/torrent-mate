// KanbanMate config — Transitions whitelist panel. The central object of the editor:
// from → to rows carrying profile / permission_mode / advance / launch marker. Editing
// a row opens a Dialog. Composes TransitionRow, Dialog, Select, Input, Textarea, Button,
// IconButton, KeyChip, ProfileTag, Banner.
const KMT = window.KanbanMateDesignSystem_2463ad;

function TransitionsPanel({ findings = [] }) {
  const data = window.KMConfigData;
  const [rows] = React.useState(data.transitions);
  const [editIdx, setEditIdx] = React.useState(null);
  const { TransitionRow, Dialog, Select, Textarea, Button, IconButton, KeyChip, ProfileTag, Banner } = KMT;

  const colKeys = data.columns.map((c) => c.key);
  const invalidIdx = new Set(findings.filter((f) => f.severity === 'error').map((f) => {
    const m = /transitions\[(\d+)\]/.exec(f.field); return m ? Number(m[1]) : -1;
  }));

  const edit = editIdx != null ? rows[editIdx] : null;
  const fmt = (v) => Array.isArray(v) ? v.join(' · ') : v;

  return (
    <div style={{ maxWidth: 900, margin: '0 auto' }}>
      <Banner tone="neutral" style={{ marginBottom: 16 }}>
        <span>The whitelist is order-sensitive — earlier rows win, and a <KeyChip>*</KeyChip> wildcard shadows specific rows below it. A row <b style={{ color: 'var(--col-agent-fg)' }}>launches</b> when its destination is an agent column.</span>
      </Banner>

      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-xs)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', borderBottom: '1px solid var(--border)', background: 'var(--muted)' }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '.06em', textTransform: 'uppercase', color: 'var(--muted-foreground)', flex: 1 }}>transitions.yml · {rows.length} rows</span>
          <Button variant="secondary" size="sm">+ Add transition</Button>
        </div>
        {rows.map((r, i) => (
          <TransitionRow key={i}
            fromCol={r.from} toCol={r.to} profile={r.profile} permissionMode={r.permission_mode}
            willLaunch={r.willLaunch} advance={r.advance} invalid={invalidIdx.has(i)}
            selected={editIdx === i} onClick={() => setEditIdx(i)}
            actions={<IconButton aria-label="edit" size="sm" onClick={(e) => { e.stopPropagation(); setEditIdx(i); }}>✎</IconButton>} />
        ))}
      </div>

      <Dialog open={edit != null} onClose={() => setEditIdx(null)} width={560}
        title={edit ? 'Edit transition' : ''}
        description={edit ? `${fmt(edit.from)} → ${fmt(edit.to)}` : ''}
        footer={<>
          <Button variant="ghost" onClick={() => setEditIdx(null)}>Cancel</Button>
          <Button variant="primary" onClick={() => setEditIdx(null)}>Apply</Button>
        </>}>
        {edit && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {invalidIdx.has(editIdx) && (
              <Banner tone="error" title="This row blocks save">
                {findings.find((f) => f.field.startsWith(`transitions[${editIdx}]`))?.message}
              </Banner>
            )}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: 12, alignItems: 'end' }}>
              <DField label="from"><Select options={['*', ...colKeys]} defaultValue={Array.isArray(edit.from) ? '*' : edit.from} style={{ width: '100%' }} /></DField>
              <span style={{ paddingBottom: 8, color: 'var(--col-agent-fg)', fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 16 }}>→</span>
              <DField label="to"><Select options={colKeys} defaultValue={edit.to} style={{ width: '100%' }} /></DField>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <DField label="profile"><Select options={['', 'docs', 'prepare', 'dev', 'check']} defaultValue={edit.profile} style={{ width: '100%' }} /></DField>
              <DField label="permission_mode"><Select options={['auto', 'default', 'plan', 'acceptEdits']} defaultValue={edit.permission_mode === 'bypassPermissions' ? 'acceptEdits' : edit.permission_mode} invalid={invalidIdx.has(editIdx)} style={{ width: '100%' }} /></DField>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <DField label="advance"><Select options={['stop', 'auto:PRCI', 'auto:Review', 'auto:Done']} defaultValue={edit.advance} style={{ width: '100%' }} /></DField>
              <DField label="on_fail"><Select options={['', 'move:Blocked', 'rollback']} defaultValue={edit.on_fail || ''} style={{ width: '100%' }} /></DField>
            </div>
            <DField label="prompt">
              <Textarea rows={3} defaultValue={edit.prompt || ''} placeholder="No prompt — script-only / no-op transition" />
            </DField>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted-foreground)', display: 'flex', alignItems: 'center', gap: 8 }}>
              launch: {edit.willLaunch
                ? <span style={{ color: 'var(--col-agent-fg)', fontWeight: 600 }}>fires agent</span>
                : <span>no-op</span>}
              · <span style={{ color: 'var(--health-blocked-fg)' }}>bypassPermissions is never allowed</span>
            </div>
          </div>
        )}
      </Dialog>
    </div>
  );
}

function DField({ label, children }) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted-foreground)' }}>{label}</span>
      {children}
    </label>
  );
}

Object.assign(window, { TransitionsPanel });

// KanbanMate configuration interface — seed data.
// Grounded in the real model: columns.yml (11 shipped columns), transitions.yml
// (whitelist rows: from→to + profile/prompt/script/advance/on_fail/permission_mode),
// defaults (concurrency_cap, move_rate_limit_per_hour) and the GitHub binding.
// Source: IznoCorp/kanban-mate — core/config_model.py, docs/columns.md.

window.KMConfigData = {
  binding: { project: 'IznoCorp/kanban-mate', branch: 'main' },

  defaults: { concurrency_cap: 3, move_rate_limit_per_hour: 10 },

  // The 11 shipped columns (docs/columns.md). class: agent | reactive | inert.
  columns: [
    { key: 'Backlog',    name: 'Backlog',      cls: 'inert',    note: 'Manual entry point. Also the reset target from Cancel.' },
    { key: 'Spec',       name: 'Spec',         cls: 'inert',    note: 'Human gate. Brainstorming is interactive.' },
    { key: 'Planned',    name: 'Planned',      cls: 'inert',    note: 'Human gate. Create-branch is interactive.' },
    { key: 'ReadyToDev', name: 'Ready to dev', cls: 'inert',    note: 'Final go / no-go before development.' },
    { key: 'InProgress', name: 'In Progress',  cls: 'agent',    note: 'Unattended-safe.', prompt: '/implement:phase',      profile: 'dev',   permission_mode: 'acceptEdits', interactive_only: false },
    { key: 'PRCI',       name: 'PR / CI',      cls: 'agent',    note: '',                 prompt: '/implement:feature-pr', profile: 'dev',   permission_mode: 'acceptEdits', interactive_only: false },
    { key: 'Review',     name: 'Review',       cls: 'agent',    note: 'No auto-merge.',   prompt: '/implement:pr-review',  profile: 'check', permission_mode: 'plan',        interactive_only: false },
    { key: 'Merge',      name: 'Merge',        cls: 'inert',    note: 'Human only — the bot cannot reach it. Merge is always a human action.' },
    { key: 'Cancel',     name: 'Cancel',       cls: 'reactive', note: 'action: teardown. Moving here kills the session. Cancel → Backlog = resume reset.', script: 'teardown.sh' },
    { key: 'Done',       name: 'Done',         cls: 'inert',    note: 'Terminal column for completed work.' },
    { key: 'Blocked',    name: 'Blocked',      cls: 'inert',    note: 'The daemon or reaper parks stalled / broken tickets here.' },
  ],

  // Whitelist transition rows (transitions.yml authoring shape). willLaunch = to_col is an agent column.
  transitions: [
    { from: 'ReadyToDev', to: 'InProgress', profile: 'dev',   permission_mode: 'acceptEdits', advance: 'auto:PRCI',   willLaunch: true,  prompt: '/implement:phase' },
    { from: 'InProgress', to: 'PRCI',       profile: 'dev',   permission_mode: 'acceptEdits', advance: 'auto:Review', willLaunch: true,  prompt: '/implement:feature-pr' },
    { from: 'PRCI',       to: 'Review',     profile: 'check', permission_mode: 'plan',        advance: 'stop',        willLaunch: true,  prompt: '/implement:pr-review' },
    { from: 'Review',     to: 'Merge',      profile: '',      permission_mode: 'auto',        advance: 'stop',        willLaunch: false, prompt: null },
    { from: ['Backlog', 'Spec', 'Planned', 'ReadyToDev'], to: 'Cancel', profile: '', permission_mode: 'auto', advance: 'stop', on_fail: '', willLaunch: false, script: 'teardown.sh' },
    { from: 'Cancel',     to: 'Backlog',    profile: '',      permission_mode: 'auto',        advance: 'stop',        willLaunch: false, prompt: null },
    { from: '*',          to: 'Blocked',    profile: '',      permission_mode: 'auto',        advance: 'stop',        willLaunch: false, prompt: null },
  ],

  // Validation findings (config_validate.py V1–V10). error blocks save; warning advisory.
  findings: [
    { severity: 'error',   field: 'transitions[2].permission_mode', message: 'permission_mode "bypassPermissions" is not allowed. bypassPermissions is NEVER allowed — use plan, acceptEdits, or auto.' },
    { severity: 'warning', field: 'transitions[6].from',            message: 'wildcard "*" shadows 2 earlier rows. Later specific transitions from the same source are unreachable — move this row last.' },
    { severity: 'warning', field: 'defaults.concurrency_cap',       message: 'concurrency_cap 3 with 4 agent edges: under burst, queued moves wait. Raise the cap or accept serialized launches.' },
  ],
};

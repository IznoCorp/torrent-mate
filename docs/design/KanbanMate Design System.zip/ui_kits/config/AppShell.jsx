// KanbanMate config — AppShell: sidebar + header chrome. Uses shadcn sidebar tokens.
const { HealthPill, Button, IconButton, Badge } = window.KanbanMateDesignSystem_2463ad;

function Wordmark({ size = 16 }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: 'var(--tracking-tight)', color: 'var(--sidebar-foreground)', lineHeight: 1, fontSize: size }}>
      <span style={{ display: 'inline-grid', placeItems: 'center', width: size * 1.6, height: size * 1.6, borderRadius: 'var(--radius-md)', background: 'var(--primary)', color: 'var(--primary-foreground)', fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: size * 0.95, flex: 'none' }}>[▸]</span>
      KanbanMate
    </span>
  );
}

const NAV = [
  { id: 'columns', label: 'Columns', key: 'columns.yml' },
  { id: 'transitions', label: 'Transitions', key: 'transitions.yml' },
  { id: 'defaults', label: 'Defaults', key: 'defaults' },
  { id: 'validation', label: 'Validation', key: 'V1–V10' },
  { id: 'yaml', label: 'YAML preview', key: 'read-only' },
];

function NavItem({ item, active, onClick, badge }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button onClick={onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, width: '100%',
        padding: '7px 10px', border: 'none', cursor: 'pointer', textAlign: 'left',
        borderRadius: 'var(--radius-md)', fontFamily: 'var(--font-sans)', fontSize: 'var(--text-sm)',
        fontWeight: active ? 600 : 500,
        color: active ? 'var(--sidebar-accent-foreground)' : 'var(--muted-foreground)',
        background: active ? 'var(--sidebar-accent)' : hover ? 'var(--sidebar-accent)' : 'transparent',
        transition: 'background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard)',
      }}>
      <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
        <span style={{ width: 6, height: 6, borderRadius: 2, flex: 'none', background: active ? 'var(--primary)' : 'var(--border)' }} />
        {item.label}
      </span>
      {badge != null && badge > 0
        ? <Badge tone="red" size="sm">{badge}</Badge>
        : <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--muted-foreground)', opacity: 0.7 }}>{item.key}</span>}
    </button>
  );
}

function AppShell({ active, onNav, errorCount = 0, dirty = false, onSave, children, mobile = false }) {
  const data = window.KMConfigData;
  const blocked = errorCount > 0;

  const sidebar = (
    <aside style={{
      width: 248, flex: 'none', display: 'flex', flexDirection: 'column',
      background: 'var(--sidebar)', borderRight: '1px solid var(--sidebar-border)',
      ...(mobile ? { display: 'none' } : {}),
    }}>
      <div style={{ padding: '16px 16px 14px', borderBottom: '1px solid var(--sidebar-border)' }}>
        <Wordmark />
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 12, fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted-foreground)' }}>
          <span style={{ width: 14, height: 14, display: 'inline-grid', placeItems: 'center' }}>⎇</span>
          {data.binding.project}
        </div>
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: 10, flex: 1 }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '.09em', textTransform: 'uppercase', color: 'var(--muted-foreground)', padding: '6px 10px 8px' }}>Configuration</div>
        {NAV.map((n) => <NavItem key={n.id} item={n} active={active === n.id} onClick={() => onNav(n.id)} badge={n.id === 'validation' ? errorCount : null} />)}
      </nav>
      <div style={{ padding: 12, borderTop: '1px solid var(--sidebar-border)', display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ width: 26, height: 26, borderRadius: '50%', background: 'var(--muted)', border: '1px solid var(--border)', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 600, color: 'var(--muted-foreground)' }}>kd</span>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--foreground)' }}>kanban daemon</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--muted-foreground)' }}>polling · 30s</div>
        </div>
      </div>
    </aside>
  );

  const headerTitle = (NAV.find((n) => n.id === active) || NAV[0]);

  return (
    <div style={{ display: 'flex', height: '100%', minHeight: 0, background: 'var(--background)', color: 'var(--foreground)' }}>
      {sidebar}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <header style={{
          display: 'flex', alignItems: 'center', gap: 14, padding: mobile ? '12px 16px' : '14px 22px',
          borderBottom: '1px solid var(--border)', background: 'color-mix(in oklch, var(--card) 86%, transparent)',
          backdropFilter: 'blur(8px)', position: 'sticky', top: 0, zIndex: 50,
        }}>
          {mobile && <span style={{ marginRight: 2 }}><Wordmark size={14} /></span>}
          <div style={{ flex: 1, minWidth: 0 }}>
            {!mobile && <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-xl)', fontWeight: 600, letterSpacing: 'var(--tracking-tight)' }}>{headerTitle.label}</h1>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted-foreground)', background: 'var(--muted)', border: '1px solid var(--border)', padding: '1px 7px', borderRadius: 'var(--radius-sm)', whiteSpace: 'nowrap' }}>{headerTitle.key}</span>
            </div>}
          </div>
          <HealthPill status={blocked ? 'BLOCKED' : dirty ? 'WAITING' : 'ACTIVE'} size="md" pulse={!blocked && !dirty} />
          <Button variant="secondary" size="md">Reload</Button>
          <Button variant="primary" size="md" disabled={blocked} onClick={onSave}>
            {blocked ? `${errorCount} error${errorCount > 1 ? 's' : ''} block save` : dirty ? 'Save config' : 'Saved'}
          </Button>
        </header>
        <main style={{ flex: 1, minHeight: 0, overflow: 'auto', padding: mobile ? '16px 16px 72px' : '22px 26px 72px', background: 'var(--background)' }}>
          {children}
        </main>
      </div>
    </div>
  );
}

Object.assign(window, { AppShell, Wordmark, KMNav: NAV });

// KanbanMate config — Columns panel. The board's 11 columns; agent columns expose
// prompt / profile / permission_mode / interactive_only. Composes ColumnClassChip,
// KeyChip, ProfileTag, Badge, Switch, IconButton, Button.
const KMNS = window.KanbanMateDesignSystem_2463ad;

function ColumnsPanel() {
  const data = window.KMConfigData;
  const [cols, setCols] = React.useState(data.columns);
  const [openKey, setOpenKey] = React.useState('InProgress');
  const { ColumnClassChip, KeyChip, ProfileTag, Badge, Switch, IconButton, Button } = KMNS;

  const count = { agent: cols.filter((c) => c.cls === 'agent').length, reactive: cols.filter((c) => c.cls === 'reactive').length, inert: cols.filter((c) => c.cls === 'inert').length };

  return (
    <div style={{ maxWidth: 880, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
        <p style={{ margin: 0, flex: 1, fontSize: 'var(--text-sm)', color: 'var(--muted-foreground)', lineHeight: 1.5 }}>
          Board columns mirror <code style={{ fontFamily: 'var(--font-mono)' }}>columns.yml</code> order. Moving a card into an <b style={{ color: 'var(--col-agent-fg)' }}>agent</b> column launches a Claude Code agent; a <b style={{ color: 'var(--col-reactive-fg)' }}>reactive</b> column runs a side-effect; <b>inert</b> columns are human gates or terminal states.
        </p>
        <Button variant="secondary" size="sm">+ Add column</Button>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><ColumnClassChip columnClass="agent" size="sm" /><span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--muted-foreground)' }}>{count.agent}</span></span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><ColumnClassChip columnClass="reactive" size="sm" /><span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--muted-foreground)' }}>{count.reactive}</span></span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><ColumnClassChip columnClass="inert" size="sm" /><span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--muted-foreground)' }}>{count.inert}</span></span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {cols.map((c, i) => {
          const open = openKey === c.key && c.cls === 'agent';
          const accent = c.cls === 'agent' ? 'var(--col-agent-solid)' : c.cls === 'reactive' ? 'var(--col-reactive-solid)' : 'transparent';
          return (
            <div key={c.key} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-xs)', overflow: 'hidden' }}>
              <div onClick={() => c.cls === 'agent' && setOpenKey(open ? null : c.key)}
                style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', cursor: c.cls === 'agent' ? 'pointer' : 'default' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted-foreground)', width: 18, flex: 'none' }}>{String(i + 1).padStart(2, '0')}</span>
                <span style={{ width: 3, height: 26, borderRadius: 2, background: accent, flex: 'none' }} />
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 9, flexWrap: 'wrap' }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-md)', color: 'var(--foreground)' }}>{c.name}</span>
                    <KeyChip>{c.key}</KeyChip>
                    {c.key === 'Merge' && <Badge tone="red" size="sm">human only</Badge>}
                  </div>
                  {c.note && <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 4, lineHeight: 1.45 }}>{c.note}</div>}
                </div>
                <ColumnClassChip columnClass={c.cls} />
                {c.cls === 'agent' && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--muted-foreground)', transform: open ? 'rotate(90deg)' : 'none', transition: 'transform var(--dur-fast) var(--ease-standard)' }}>›</span>}
              </div>
              {open && (
                <div style={{ borderTop: '1px solid var(--border)', background: 'var(--muted)', padding: '14px 14px 14px 50px', display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0,1fr))', gap: 14 }}>
                  <Field label="prompt"><KeyChip tone="token">{c.prompt}</KeyChip></Field>
                  <Field label="permission_profile"><ProfileTag profile={c.profile} /></Field>
                  <Field label="permission_mode"><KeyChip>{c.permission_mode}</KeyChip></Field>
                  <Field label="interactive_only">
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                      <Switch checked={!!c.interactive_only} size="sm" onChange={() => {}} />
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--muted-foreground)' }}>{c.interactive_only ? 'true' : 'false — fires unattended'}</span>
                    </span>
                  </Field>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '.06em', textTransform: 'uppercase', color: 'var(--muted-foreground)' }}>{label}</span>
      <span>{children}</span>
    </div>
  );
}

Object.assign(window, { ColumnsPanel });

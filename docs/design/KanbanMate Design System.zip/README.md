# KanbanMate Design System

A design system for **KanbanMate** — a reusable Kanban orchestrator built on **GitHub Projects v2**
that dispatches autonomous **Claude Code agents** onto roadmap tickets. Each card is moved column by
column on a board; moving a card into a *triggering column* fires an agent in an isolated tmux +
git-worktree workspace. A single background daemon polls the board and reconciles it against
persisted state.

This system exists to re-design and unify **KanbanMate's configuration interface** (introduced as a
headless API in [PR #33](https://github.com/IznoCorp/kanban-mate/pull/33)) and to govern all future
KanbanMate interfaces — **desktop and mobile**.

> **Why this system was built from scratch:** KanbanMate is a Python CLI + Claude plugin. It ships
> **no brand assets, no colors, no typefaces, no logo** — its only "interface" so far is the terminal
> and a headless FastAPI config server. So the visual identity here is *defined*, grounded in the
> product's real domain model (columns, transitions, agents, health states), not lifted from an
> existing UI.

---

## Sources

Everything here was derived from the KanbanMate codebase. The reader is encouraged to explore these
to build more faithful KanbanMate designs:

- **GitHub repo:** [`IznoCorp/kanban-mate`](https://github.com/IznoCorp/kanban-mate) (private)
- **The configuration interface this system re-designs:**
  [PR #33 — configuration interface](https://github.com/IznoCorp/kanban-mate/pull/33)
- Key files read to ground the domain model:
  - `src/kanbanmate/core/config_model.py` — the editable `PipelineDraft` (columns, transitions, defaults, binding)
  - `src/kanbanmate/core/config_validate.py` — the 10 semantic validation checks (V1–V10) and `Finding` model
  - `src/kanbanmate/http/config_api.py` — the 7-endpoint headless config API the UI consumes
  - `docs/columns.md` — the board column reference (agent / reactive / inert classes; the 11 shipped columns)
  - `README.md` / `CLAUDE.md` — product overview + the **health vocabulary** (`INACTIVE · BLOCKED · WAITING · ACTIVE · COMPLETE`)

No design files (Figma, screenshots) were provided — none exist. The visual language is original,
built to fit a precise developer-tooling product.

---

## Foundation: built over shadcn/ui

This system is **founded on [shadcn/ui](https://ui.shadcn.com/)**. shadcn is the canonical layer:

- **Tokens** — `tokens/colors.css` ships the full shadcn token set in **oklch**, exactly as shadcn
  defines it: `--background · --foreground · --card · --popover · --primary · --secondary · --muted ·
  --accent · --destructive · --border · --input · --ring`, the five `--chart-*` tokens, and the
  `--sidebar*` family. Light values on `:root`, dark on `.dark` **and** `[data-theme="dark"]`.
- **Two brand decisions on top of stock shadcn:**
  1. `--primary` is keyed to KanbanMate's **signal green** (the product keeps work *flowing* — ACTIVE
     is the healthy state), not shadcn's neutral near-black.
  2. The five **health states** and three **column classes** are brand *extensions* that live beside
     the shadcn tokens (`--health-*`, `--col-*`), never inside them.
- **Legacy aliases remap onto shadcn.** Older semantic names (`--surface-*`, `--text-*`, `--border-*`,
  `--accent-*`) now resolve to the shadcn tokens, so there is a single source of truth.
- **Radius** follows shadcn's scale — `--radius: 0.625rem` with `--radius-sm/md/lg/xl` derived via
  `calc()`. **Shadows** align to shadcn's `shadow-2xs … shadow-lg` and the focus ring is shadcn's
  3px `--ring` halo.
- **Type** is shadcn's native stack: **Geist** (UI, display) + **Geist Mono** (every literal
  identifier the daemon reads). See the *Font substitution* note below.
- **Components** follow shadcn "New York": `h-9` controls, `rounded-md` buttons/inputs with
  `shadow-xs`, `rounded-xl` cards, focus-visible ring.

> **Font note / substitution:** KanbanMate ships no brand typeface. Geist is shadcn's default and is
> loaded from Google Fonts. If the team adopts a different brand face, drop the files into `tokens/`
> and swap the `@import` in `tokens/fonts.css`.

---

## What KanbanMate is (domain primer)

The product's nouns drive every component in this system:

| Concept | What it is |
| --- | --- |
| **Board** | A GitHub Projects v2 board; cards (tickets) flow left→right through columns. |
| **Column class** | `agent` (moving a card here launches a Claude Code agent), `reactive` (runs a mechanical side-effect like teardown — e.g. *Cancel*), or `inert` (a human gate or terminal state). |
| **Transition** | A whitelist row: `from_col → to_col` carrying a `profile`, `prompt`, `script`, `advance`, `on_fail`, and `permission_mode`. This is what the config editor edits. |
| **Defaults** | Board-wide `concurrency_cap` and `move_rate_limit_per_hour`. |
| **Health** | The single rolling status pill: `INACTIVE · BLOCKED · WAITING · ACTIVE · COMPLETE`. The heart of the dashboard. |
| **Finding** | A validation result — `error` (blocks save) or `warning` (advisory) — anchored to a field locus like `transitions[3].permission_mode`. |
| **Profile** | A permission profile: `docs · prepare · dev · check`. Merge is always human-only. |

---

## Content Fundamentals — how KanbanMate writes

KanbanMate's voice is **precise, terse, and operator-to-operator.** It is documentation written by
engineers for engineers running an autonomous system; it never markets, never cheerleads.

- **Person & address.** Imperative and second-person for actions the operator takes: *"Resume
  orchestration with `kanban resume`."* *"Open the ticket, read the agent's last comment, fix the
  blocker."* The system describes itself in third person: *"The daemon maintains one rolling status
  update."* Never "we," rarely "you" as a subject — the operator is addressed through verbs.
- **Casing.** Sentence case everywhere in prose and UI labels. **SCREAMING-CASE is reserved** and
  *meaningful*: it marks the health vocabulary (`ACTIVE`, `BLOCKED`) and GitHub enum states. Don't
  uppercase for emphasis — uppercase *is* a state.
- **Identifiers are literal and monospace.** Column keys (`InProgress`), permission modes
  (`bypassPermissions`), commands (`kanban status`), placeholder tokens (`{{branch}}`), file paths
  (`columns.yml`) are always set in mono and spelled exactly as the daemon reads them. The UI and
  the config file must read identically.
- **Terse, mechanism-first.** Sentences lead with what happens, then why. *"Moving here kills the
  session. Cancel → Backlog = resume reset."* Tables and arrows (`→`) over paragraphs. Em-dashes and
  parentheticals carry the precise caveats.
- **Errors are located and actionable.** A finding names the exact field and the fix, never a vague
  apology: *"permission_mode 'bypassPermissions' is not allowed. bypassPermissions is NEVER allowed."*
  Severity is explicit (`error` blocks save; `warning` is advisory).
- **Safety is stated plainly and absolutely.** *"Merge = human only."* *"The daemon and agents run
  non-root."* No hedging on the guardrails.
- **No emoji. No exclamation marks** (outside a rare *"That's it."*). **Bilingual reality:** the team
  works in French and English; code, comments, and these artifacts are English. Tone is calm,
  confident, and dry.

**Microcopy specimens** (use verbatim style):
- Empty board: *"No tickets yet. Seed the board from your roadmap: `kanban seed ROADMAP.md`."*
- Save blocked: *"3 errors block save. Fix the located fields below — nothing is written until they pass."*
- Agent firing: *"In Progress → agent fires. `/implement:phase`, profile `dev`, unattended-safe."*

---

## Visual Foundations

The aesthetic is **engineered control surface** — terminal-adjacent precision, not a marketing site.
Dense, quiet, legible; the data is the decoration.

- **Color.** A warm-graphite neutral base (`--gray-*`, very slightly warm so it reads like paper /
  brushed metal, not clinical blue-gray). One **brand accent — signal green** (`--green-500
  #1f9d54`), used sparingly for primary actions, the wordmark, and the *ACTIVE* state. Green is
  deliberate: KanbanMate's whole job is keeping work *flowing*, and `ACTIVE → On track` is the
  healthy state. The five **health states** each own a hue (inactive=slate, blocked=red,
  waiting=amber, active=green, complete=blue); the three **column classes** own theirs
  (agent=violet — the one earned second hue, reactive=amber, inert=neutral). Every color is a
  semantic alias; components never touch raw ramps. Full light + dark themes via `[data-theme]`.
- **Type.** Three families, all substitutes (see Iconography/Fonts note): **Space Grotesk** (display,
  wordmark, big numerics — geometric and engineered), **IBM Plex Sans** (body & UI), **IBM Plex
  Mono** (every literal identifier — keys, YAML, prompts, data). The mono is load-bearing: it's how
  the UI signals "this string is exactly what the daemon reads."
- **Spacing & density.** Tight 4px grid. This is a config editor and a board — information-dense by
  design. Generous whitespace is spent on *grouping*, not breathing room.
- **Borders over shadows.** Elevation comes primarily from **1px borders** (`--border-subtle` →
  `--border-strong`), not drop shadows. Shadows are restrained (`--shadow-xs`…`--shadow-lg`) and
  reserved for true overlays (popovers, dialogs, dragged cards). Cards = white surface + 1px subtle
  border + small radius + at most `--shadow-sm`.
- **Corner radii.** Small and technical: `--radius-sm 5px` / `--radius-md 7px` for controls and
  cards; `--radius-pill` only for status pills and badges. Nothing is bubbly.
- **Backgrounds.** Flat surfaces. **No gradients** as decoration (the only acceptable gradient is a
  functional scrim behind a sticky toolbar or a drag overlay). No illustrations, no photography, no
  textures — a faint dotted grid is the *only* sanctioned background pattern, used behind the board
  canvas to read as graph paper.
- **Motion.** Snappy, no bounce — `--ease-standard` / `--ease-out`, 110–240ms. Fades and short
  translates only. Drag is the one place motion is expressive (a card lifts with `--shadow-lg` and a
  ~1.5° tilt). Respect `prefers-reduced-motion`.
- **States.** *Hover* = surface darkens one step (`--surface-hover`) or accent deepens
  (`--accent-hover`); never a glow. *Press* = surface goes one step further (`--surface-active`) +
  subtle 1px inset feel; no scale-down on buttons (scale is reserved for draggable cards). *Focus* =
  a 3px soft ring (`--shadow-focus` using `--ring`), always visible, accent-tinted.
- **Transparency & blur.** Used sparingly and functionally: sticky headers get a translucent surface
  + `backdrop-filter: blur` so dense content scrolls under them legibly; dialog scrims are a flat
  semi-opaque ink, not blurred. Never decorative glassmorphism.
- **The brand mark — "flow bracket".** A monospace bracket enclosing a play glyph: **`[▸]`** — a
  card entering a triggering column. Rendered as a small solid-green rounded square with a mono
  glyph, set beside the Geist wordmark. It scales from a 16px favicon to a board header.

---

## Iconography

KanbanMate ships **no icon assets** — the codebase is a CLI, its only "icons" are Unicode arrows
(`→`) and ASCII flow diagrams in docs. So this system adopts:

- **[Lucide](https://lucide.dev)** (loaded from CDN) as the icon set — a clean, consistent
  1.5–2px-stroke open line icon family that matches the engineered, technical tone and dark/light
  themes. **This is a substitution; flagged below.** Stroke icons (not filled) keep parity with the
  thin-border elevation language. Sizes: 14/16/18/20px in UI; never larger than the text beside them
  by more than ~1.2×.
- **Unicode arrows stay literal.** Transitions are written `from → to` with a real `→` (U+2192),
  matching the docs' flow diagrams — not an icon. The "flow bracket" `[▸]` brand glyph is typeset,
  not an SVG.
- **State is carried by color + shape, not icon novelty.** Health pills and column-class chips use a
  small filled dot + label, not a unique glyph per state — color does the work.
- **No emoji, ever.** Consistent with the product's voice.

> ⚠️ **Substitution flags (please confirm or replace):**
> 1. **Fonts** — **Geist / Geist Mono** (shadcn's native stack) loaded from Google Fonts; KanbanMate
>    has no brand typeface. If you adopt official fonts, drop the files in `tokens/` and swap
>    `tokens/fonts.css`.
> 2. **Icons** — Lucide via CDN, substituting for a non-existent KanbanMate icon set.
> 3. **Brand color** — signal green is keyed to shadcn's `--primary` as a defined choice, not an
>    extracted brand color.
> Tell me if KanbanMate has (or wants) a different palette and I'll re-key the whole system.

---

## Index / manifest

Root:
- **`styles.css`** — the single entry point consumers link (imports-only).
- **`tokens/`** — `fonts.css` (Geist + Geist Mono), `colors.css` (shadcn oklch tokens), `typography.css`, `spacing.css`, `base.css`.
- **`README.md`** — this file.
- **`SKILL.md`** — Agent-Skills-compatible entry for use in Claude Code.

Foundations (Design System tab cards): `guidelines/` — color, type, spacing, status & column-class,
and brand specimen cards.

Components (`components/`): reusable React primitives — see each directory's card.
- `core/` — Button, IconButton, Input, Select, Textarea, Switch, Checkbox, SegmentedControl
- `data-display/` — Badge, HealthPill, ColumnClassChip, KeyChip, Avatar, ProfileTag
- `kanban/` — ColumnCard, TicketCard, TransitionRow, FindingItem
- `feedback/` — Banner, Dialog, Tooltip

UI kits (`ui_kits/`):
- `config/` — **the KanbanMate configuration interface** (desktop + mobile): board columns editor,
  transition whitelist editor, validation panel, defaults, and YAML preview.

---

*Generated assets register automatically in the Design System tab. See `SKILL.md` to use this system
inside Claude Code.*

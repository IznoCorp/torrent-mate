---
name: kanbanmate-design
description: Use this skill to generate well-branded interfaces and assets for KanbanMate, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. Built over shadcn/ui.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

KanbanMate's design system is **built over [shadcn/ui](https://ui.shadcn.com/)**: the token layer in
`tokens/colors.css` is the canonical shadcn oklch token set (`--background`, `--card`, `--primary`,
`--secondary`, `--muted`, `--accent`, `--destructive`, `--border`, `--input`, `--ring`, `--chart-*`,
`--sidebar*`), with `--primary` keyed to KanbanMate's signal green. Type is **Geist + Geist Mono**.
The five health states (`--health-*`) and three column classes (`--col-*`) are brand extensions.

Key files:
- `styles.css` — single entry point; `@import`s every token + font file.
- `tokens/` — colors (shadcn), typography, spacing/radius/shadow, fonts, base.
- `components/` — reusable React primitives (Button, Input, Select, Switch, Card, Badge, Dialog,
  plus KanbanMate-specific: HealthPill, ColumnClassChip, KeyChip, ProfileTag, TransitionRow,
  ColumnCard, TicketCard, FindingItem).
- `ui_kits/config/` — the configuration interface (PR #33) recreated on shadcn, desktop + mobile.
- `guidelines/` — foundation specimen cards.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create
static HTML files for the user to view. If working on production code, copy assets and read the rules
here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design,
ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code,
depending on the need.

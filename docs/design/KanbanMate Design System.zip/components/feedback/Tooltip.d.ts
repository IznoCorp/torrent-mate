import * as React from 'react';

export interface TooltipProps {
  label: React.ReactNode;
  placement?: 'top' | 'bottom' | 'left' | 'right';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Hover tooltip on the dark inverse surface. */
export function Tooltip(props: TooltipProps): JSX.Element;

import * as React from 'react';

export interface DialogProps {
  open?: boolean;
  title?: React.ReactNode;
  description?: React.ReactNode;
  /** Right-aligned footer actions (e.g. Cancel / Save buttons). */
  footer?: React.ReactNode;
  onClose?: () => void;
  width?: number;
  children?: React.ReactNode;
}

/** Modal dialog with a flat ink scrim — edit a transition, confirm, preview YAML. */
export function Dialog(props: DialogProps): JSX.Element | null;

import * as React from 'react';

export interface BannerProps {
  tone?: 'info' | 'success' | 'warning' | 'error' | 'neutral';
  title?: React.ReactNode;
  icon?: React.ReactNode;
  action?: React.ReactNode;
  onDismiss?: (() => void) | null;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Inline message banner (info / success / warning / error / neutral). */
export function Banner(props: BannerProps): JSX.Element;

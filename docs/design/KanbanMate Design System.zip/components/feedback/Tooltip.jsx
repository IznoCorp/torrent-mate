import React from 'react';

/**
 * Lightweight hover tooltip on the dark inverse surface. Wraps any trigger;
 * shows `label` above it. For terse hints (what a permission_mode does, etc).
 */
export function Tooltip({ label, children, placement = 'top', style }) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: { bottom: '100%', left: '50%', transform: 'translateX(-50%)', marginBottom: 6 },
    bottom: { top: '100%', left: '50%', transform: 'translateX(-50%)', marginTop: 6 },
    right: { left: '100%', top: '50%', transform: 'translateY(-50%)', marginLeft: 6 },
    left: { right: '100%', top: '50%', transform: 'translateY(-50%)', marginRight: 6 },
  }[placement];
  return (
    <span
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
      onFocus={() => setShow(true)}
      onBlur={() => setShow(false)}
      style={{ position: 'relative', display: 'inline-flex', ...style }}
    >
      {children}
      {show && (
        <span
          role="tooltip"
          style={{
            position: 'absolute', zIndex: 300, ...pos, whiteSpace: 'nowrap', pointerEvents: 'none',
            background: 'var(--surface-inverse)', color: 'var(--text-inverse)',
            fontFamily: 'var(--font-sans)', fontSize: 'var(--text-xs)', fontWeight: 500,
            padding: '5px 9px', borderRadius: 'var(--radius-xs)', boxShadow: 'var(--shadow-md)',
            animation: 'km-tip var(--dur-fast) var(--ease-out)',
          }}
        >
          <style>{'@keyframes km-tip{from{opacity:0}to{opacity:1}}'}</style>
          {label}
        </span>
      )}
    </span>
  );
}

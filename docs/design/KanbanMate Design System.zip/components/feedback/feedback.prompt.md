**Feedback** — Banner, Dialog, Tooltip.

```jsx
<Banner tone="error" title="3 errors block save">
  Fix the located fields below — nothing is written until they pass.
</Banner>

<Dialog open={open} title="Edit transition" onClose={close}
  footer={<><Button variant="ghost" onClick={close}>Cancel</Button><Button variant="primary">Save</Button></>}>
  …form…
</Dialog>

<Tooltip label="acceptEdits — auto-accepts file edits"><KeyChip>acceptEdits</KeyChip></Tooltip>
```

Dialog uses a flat ink scrim (no glassmorphism). Banner tones match the validation/severity palette.

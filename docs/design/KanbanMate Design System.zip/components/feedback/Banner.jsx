import React from 'react';

/**
 * Inline message banner. `tone` carries intent; the save-blocked summary, the
 * "config reloaded" notice, and warnings all use this. Optional title + action.
 */
export function Banner({ tone = 'info', title = null, children, icon = null, action = null, onDismiss = null, style }) {
  const tones = {
    info: { fg: 'var(--blue-700)', bg: 'var(--blue-50)', bd: 'var(--blue-300)' },
    success: { fg: 'var(--green-700)', bg: 'var(--green-50)', bd: 'var(--green-300)' },
    warning: { fg: 'var(--amber-700)', bg: 'var(--amber-50)', bd: 'var(--amber-300)' },
    error: { fg: 'var(--red-700)', bg: 'var(--red-50)', bd: 'var(--red-300)' },
    neutral: { fg: 'var(--text-body)', bg: 'var(--surface-sunken)', bd: 'var(--border-subtle)' },
  };
  const t = tones[tone] || tones.info;
  return (
    <div style={{ display: 'flex', gap: 'var(--space-5)', padding: '11px 13px', background: t.bg, border: `1px solid ${t.bd}`, borderRadius: 'var(--radius-sm)', ...style }}>
      {icon != null ? <span style={{ color: t.fg, flex: 'none', marginTop: 1 }}>{icon}</span>
        : <span style={{ width: 7, height: 7, borderRadius: '50%', background: t.fg, flex: 'none', marginTop: 6 }} />}
      <div style={{ flex: 1, minWidth: 0 }}>
        {title && <div style={{ fontWeight: 'var(--weight-semibold)', fontSize: 'var(--text-sm)', color: t.fg, marginBottom: children ? 2 : 0 }}>{title}</div>}
        {children && <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-body)', lineHeight: 1.5 }}>{children}</div>}
      </div>
      {action}
      {onDismiss && <button onClick={onDismiss} aria-label="Dismiss" style={{ flex: 'none', border: 'none', background: 'transparent', color: t.fg, cursor: 'pointer', fontSize: 15, lineHeight: 1, opacity: 0.7 }}>×</button>}
    </div>
  );
}

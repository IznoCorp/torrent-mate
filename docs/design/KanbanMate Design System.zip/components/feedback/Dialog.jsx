import React from 'react';

/**
 * Modal dialog with a flat ink scrim (no blur) and a bordered surface. Used for
 * editing a transition, confirming a destructive action, or the YAML preview.
 */
export function Dialog({ open = false, title = null, description = null, children, footer = null, onClose, width = 480 }) {
  if (!open) return null;
  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 400, display: 'grid', placeItems: 'center', padding: 'var(--space-7)',
        background: 'color-mix(in oklch, var(--gray-950) 52%, transparent)',
        animation: 'km-fade var(--dur-base) var(--ease-standard)',
      }}
    >
      <style>{'@keyframes km-fade{from{opacity:0}to{opacity:1}}@keyframes km-pop{from{opacity:0;transform:translateY(6px) scale(.99)}to{opacity:1;transform:none}}'}</style>
      <div
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: width, maxHeight: '88vh', display: 'flex', flexDirection: 'column',
          background: 'var(--surface-raised)', border: '1px solid var(--border-default)',
          borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)', overflow: 'hidden',
          animation: 'km-pop var(--dur-base) var(--ease-out)',
        }}
      >
        {(title || onClose) && (
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--space-5)', padding: '14px 16px', borderBottom: '1px solid var(--border-subtle)' }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              {title && <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-lg)', color: 'var(--text-strong)' }}>{title}</div>}
              {description && <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', marginTop: 3 }}>{description}</div>}
            </div>
            {onClose && <button onClick={onClose} aria-label="Close" style={{ flex: 'none', width: 28, height: 28, display: 'grid', placeItems: 'center', border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', borderRadius: 'var(--radius-xs)', fontSize: 17 }}>×</button>}
          </div>
        )}
        <div style={{ padding: 16, overflow: 'auto', flex: 1 }}>{children}</div>
        {footer && <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--space-4)', padding: '12px 16px', borderTop: '1px solid var(--border-subtle)', background: 'var(--surface-app)' }}>{footer}</div>}
      </div>
    </div>
  );
}

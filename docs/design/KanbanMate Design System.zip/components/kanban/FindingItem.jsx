import React from 'react';

/**
 * A single validation Finding (config_validate.py). `error` blocks save and
 * paints red; `warning` is advisory amber. Shows the dot-path field locus in
 * mono and the message, matching the API's `{field, message, severity}` shape.
 */
export function FindingItem({ severity = 'error', field, message, onClick, style }) {
  const isErr = severity === 'error';
  const c = isErr
    ? { fg: 'var(--red-700)', bg: 'var(--red-50)', bd: 'var(--red-300)', dot: 'var(--red-500)', label: 'error' }
    : { fg: 'var(--amber-700)', bg: 'var(--amber-50)', bd: 'var(--amber-300)', dot: 'var(--amber-500)', label: 'warning' };
  return (
    <div
      onClick={onClick}
      style={{
        display: 'flex', gap: 'var(--space-5)', padding: '10px 12px',
        background: c.bg, border: `1px solid ${c.bd}`, borderRadius: 'var(--radius-sm)',
        cursor: onClick ? 'pointer' : 'default', ...style,
      }}
    >
      <span style={{ width: 8, height: 8, borderRadius: '50%', background: c.dot, flex: 'none', marginTop: 5 }} />
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: c.fg }}>{c.label}</span>
          {field && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: c.fg, opacity: 0.85, background: 'rgba(0,0,0,0.04)', padding: '1px 5px', borderRadius: 'var(--radius-xs)' }}>{field}</span>}
        </div>
        <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-body)', lineHeight: 1.45 }}>{message}</div>
      </div>
    </div>
  );
}

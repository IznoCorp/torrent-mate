import * as React from 'react';

export interface ColumnCardProps {
  name: string;
  columnKey: string;
  columnClass?: 'agent' | 'reactive' | 'inert';
  count?: number;
  selected?: boolean;
  onClick?: () => void;
  /** TicketCards to render inside the lane. */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * A board column lane — name, mono key, class chip, count, optional tickets.
 *
 * @startingPoint section="Kanban" subtitle="Board column lane with class + count" viewport="320x420"
 */
export function ColumnCard(props: ColumnCardProps): JSX.Element;

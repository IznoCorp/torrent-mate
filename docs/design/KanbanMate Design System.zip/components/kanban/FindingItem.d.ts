import * as React from 'react';

export interface FindingItemProps {
  severity?: 'error' | 'warning';
  /** Dot-path field locus, e.g. "transitions[3].permission_mode". */
  field?: string;
  message: string;
  /** Click to jump to / focus the offending field. */
  onClick?: () => void;
  style?: React.CSSProperties;
}

/** A validation finding (error blocks save; warning is advisory). */
export function FindingItem(props: FindingItemProps): JSX.Element;

import React from 'react';

const CLASS_TONE = {
  agent: { fg: 'var(--col-agent-fg)', bg: 'var(--col-agent-bg)', bd: 'var(--col-agent-bd)', solid: 'var(--col-agent-solid)' },
  reactive: { fg: 'var(--col-reactive-fg)', bg: 'var(--col-reactive-bg)', bd: 'var(--col-reactive-bd)', solid: 'var(--col-reactive-solid)' },
  inert: { fg: 'var(--col-inert-fg)', bg: 'var(--col-inert-bg)', bd: 'var(--col-inert-bd)', solid: 'var(--col-inert-solid)' },
};

/**
 * A board column header/lane. Shows the human name, the mono key, the class
 * chip, and a ticket count. Agent/reactive columns get a thin top accent rule in
 * their class colour so a glance down the board reads the pipeline shape.
 * Self-contained (renders its own class chip) so it has no cross-component deps.
 */
export function ColumnCard({ name, columnKey, columnClass = 'inert', count = 0, children, selected = false, onClick, style }) {
  const c = CLASS_TONE[columnClass] || CLASS_TONE.inert;
  const accent = columnClass === 'inert' ? 'transparent' : c.solid;
  return (
    <div
      onClick={onClick}
      style={{
        display: 'flex', flexDirection: 'column', minWidth: 0,
        background: 'var(--surface-card)', border: `1px solid ${selected ? 'var(--border-focus)' : 'var(--border-subtle)'}`,
        borderRadius: 'var(--radius-md)', overflow: 'hidden',
        boxShadow: selected ? 'var(--shadow-focus)' : 'var(--shadow-xs)',
        cursor: onClick ? 'pointer' : 'default', ...style,
      }}
    >
      <div style={{ height: 3, background: accent, flex: 'none' }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', padding: '10px 12px', borderBottom: children ? '1px solid var(--border-subtle)' : 'none' }}>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-md)', color: 'var(--text-strong)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-subtle)' }}>{count}</span>
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-subtle)', marginTop: 2 }}>{columnKey}</div>
        </div>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, height: 18, padding: '0 7px', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', fontWeight: 600, color: c.fg, background: c.bg, border: `1px solid ${c.bd}`, borderRadius: 'var(--radius-xs)', whiteSpace: 'nowrap' }}>
          <span style={{ width: 7, height: 7, borderRadius: 2, background: c.solid, flex: 'none' }} />{columnClass}
        </span>
      </div>
      {children && <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: 10, background: 'var(--surface-app)' }}>{children}</div>}
    </div>
  );
}

import React from 'react';
import { HealthPill } from '../data-display/HealthPill.jsx';
import { Avatar } from '../data-display/Avatar.jsx';

/**
 * A ticket card as it sits in a board lane. Shows the issue number + title, an
 * optional running-agent row, and an optional health dot. Lifts on hover; tilts
 * + heavy-shadows while dragging.
 */
export function TicketCard({ number, title, agent = null, health = null, dragging = false, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: 'var(--surface-card)', border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-sm)', padding: '9px 11px', cursor: onClick ? 'pointer' : 'grab',
        boxShadow: dragging ? 'var(--shadow-lg)' : hover ? 'var(--shadow-sm)' : 'var(--shadow-xs)',
        transform: dragging ? 'rotate(1.5deg)' : 'none',
        transition: 'box-shadow var(--dur-fast) var(--ease-standard), transform var(--dur-fast) var(--ease-out)',
        ...style,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-subtle)', paddingTop: 1 }}>#{number}</span>
        <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-strong)', fontWeight: 'var(--weight-medium)', lineHeight: 1.35, flex: 1, minWidth: 0 }}>{title}</span>
        {health && <span style={{ width: 8, height: 8, borderRadius: '50%', background: `var(--health-${String(health).toLowerCase()}-fg)`, flex: 'none', marginTop: 4 }} />}
      </div>
      {agent && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 9, paddingTop: 8, borderTop: '1px solid var(--border-subtle)' }}>
          <Avatar kind="agent" label={agent.label || 'A'} size="xs" />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-muted)', flex: 1, minWidth: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{agent.session || agent.label}</span>
          {agent.status && <HealthPill status={agent.status} size="sm" pulse={agent.status === 'ACTIVE'} />}
        </div>
      )}
    </div>
  );
}

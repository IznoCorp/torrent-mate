import * as React from 'react';

export interface TransitionRowProps {
  /** Source column key, "*" wildcard, or a list (authoring sugar). */
  fromCol: string | string[];
  toCol: string | string[];
  profile?: 'docs' | 'prepare' | 'dev' | 'check' | 'merge' | '';
  permissionMode?: string;
  /** True when the transition carries a prompt (an agent fires). */
  willLaunch?: boolean;
  advance?: string;
  selected?: boolean;
  /** Paints the red error rail (a finding targets this row). */
  invalid?: boolean;
  onClick?: () => void;
  /** Trailing action nodes (e.g. an IconButton delete). */
  actions?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * A whitelist transition row (from → to + profile + permission_mode + launch
 * marker) — the central object of the KanbanMate config editor.
 *
 * @startingPoint section="Kanban" subtitle="Transition whitelist row" viewport="700x70"
 */
export function TransitionRow(props: TransitionRowProps): JSX.Element;

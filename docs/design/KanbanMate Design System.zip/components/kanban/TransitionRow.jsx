import React from 'react';
import { ProfileTag } from '../data-display/ProfileTag.jsx';
import { KeyChip } from '../data-display/KeyChip.jsx';

/**
 * One whitelist transition row in the config editor: `from → to` plus its
 * profile, permission_mode, and a launch/no-op marker. This is the central
 * object of the configuration interface. `invalid` paints the error rail used
 * when a validation finding targets this row.
 */
export function TransitionRow({
  fromCol, toCol, profile = '', permissionMode = 'auto', willLaunch = false,
  advance = 'stop', selected = false, invalid = false, onClick, actions = null, style,
}) {
  const [hover, setHover] = React.useState(false);
  const rail = invalid ? 'var(--red-500)' : selected ? 'var(--border-focus)' : 'transparent';
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 'var(--space-5)', padding: '10px 12px 10px 10px',
        background: selected ? 'var(--accent-weak)' : hover ? 'var(--surface-hover)' : 'var(--surface-card)',
        borderLeft: `2.5px solid ${rail}`,
        borderBottom: '1px solid var(--border-subtle)', cursor: onClick ? 'pointer' : 'default',
        transition: 'background var(--dur-fast) var(--ease-standard)', ...style,
      }}
    >
      <span style={{ color: 'var(--text-subtle)', cursor: 'grab', fontSize: 13, flex: 'none', lineHeight: 1 }}>⠿</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 0, flexWrap: 'wrap' }}>
        <KeyChip>{Array.isArray(fromCol) ? fromCol.join(' · ') : fromCol}</KeyChip>
        <span style={{ color: 'var(--col-agent-fg)', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>→</span>
        <KeyChip tone="accent">{Array.isArray(toCol) ? toCol.join(' · ') : toCol}</KeyChip>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 'none' }}>
        {willLaunch
          ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', fontWeight: 600, color: 'var(--col-agent-fg)' }}><span style={{ width: 6, height: 6, borderRadius: 2, background: 'var(--col-agent-solid)' }} />launches</span>
          : <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-subtle)' }}>no-op</span>}
        <ProfileTag profile={profile} size="sm" />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-muted)', minWidth: 84, textAlign: 'right' }}>{permissionMode}</span>
        {actions}
      </div>
    </div>
  );
}

**Board & config objects** — ColumnCard, TicketCard, TransitionRow, FindingItem.

```jsx
<ColumnCard name="In Progress" columnKey="InProgress" columnClass="agent" count={3}>
  <TicketCard number={12} title="Wire the reaper audit gate"
    agent={{ label: 'ticket-12', session: 'ticket-12', status: 'ACTIVE' }} />
</ColumnCard>

<TransitionRow fromCol="InProgress" toCol="PRCI" profile="dev"
  permissionMode="acceptEdits" willLaunch />

<FindingItem severity="error" field="transitions[3].permission_mode"
  message="permission_mode 'bypassPermissions' is not allowed." />
```

These compose the config interface and the live board. TransitionRow + FindingItem mirror the `config_model` / `config_validate` shapes exactly.

import * as React from 'react';
import type { HealthStatus } from '../data-display/HealthPill';

export interface TicketAgent {
  label: string;
  session?: string;
  status?: HealthStatus;
}

export interface TicketCardProps {
  number: number | string;
  title: string;
  /** Running-agent row (avatar + session + health). */
  agent?: TicketAgent | null;
  /** Health dot in the corner. */
  health?: HealthStatus | null;
  dragging?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/** A ticket card in a board lane, with optional running-agent row. */
export function TicketCard(props: TicketCardProps): JSX.Element;

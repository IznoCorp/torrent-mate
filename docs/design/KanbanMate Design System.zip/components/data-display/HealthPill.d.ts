import * as React from 'react';

export type HealthStatus = 'INACTIVE' | 'BLOCKED' | 'WAITING' | 'ACTIVE' | 'COMPLETE';

export interface HealthPillProps {
  status?: HealthStatus;
  size?: 'sm' | 'md' | 'lg';
  /** Animate the dot (use for the live ACTIVE state). */
  pulse?: boolean;
  /** Append the GitHub pill label (e.g. "On track"). */
  showGithub?: boolean;
  style?: React.CSSProperties;
}

/**
 * KanbanMate's dashboard health pill — the five-state status vocabulary
 * (INACTIVE · BLOCKED · WAITING · ACTIVE · COMPLETE) that maps onto GitHub's pill.
 *
 * @startingPoint section="Data display" subtitle="The five-state health pill" viewport="700x140"
 */
export function HealthPill(props: HealthPillProps): JSX.Element;

import * as React from 'react';

export interface ProfileTagProps {
  /** Permission profile name; '' renders a dashed "no profile" tag. */
  profile?: 'docs' | 'prepare' | 'dev' | 'check' | 'merge' | '';
  size?: 'sm' | 'md';
  style?: React.CSSProperties;
}

/** Permission-profile tag with a per-profile tone. */
export function ProfileTag(props: ProfileTagProps): JSX.Element;

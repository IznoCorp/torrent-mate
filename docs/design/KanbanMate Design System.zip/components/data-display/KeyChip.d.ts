import * as React from 'react';

export interface KeyChipProps {
  tone?: 'neutral' | 'accent' | 'token';
  /** Adds click-to-copy. */
  copyable?: boolean;
  size?: 'sm' | 'md';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Monospace chip for a literal identifier (column key, {{token}}, path). */
export function KeyChip(props: KeyChipProps): JSX.Element;

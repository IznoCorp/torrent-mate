import React from 'react';

const PROFILES = {
  docs: 'blue', prepare: 'neutral', dev: 'accent', check: 'violet', merge: 'red', '': 'neutral',
};
const TONES = {
  neutral: { fg: 'var(--text-muted)', bg: 'var(--surface-sunken)', bd: 'var(--border-subtle)' },
  accent: { fg: 'var(--accent-text)', bg: 'var(--accent-weak)', bd: 'var(--accent-weak-border)' },
  blue: { fg: 'var(--blue-700)', bg: 'var(--blue-50)', bd: 'var(--blue-300)' },
  violet: { fg: 'var(--violet-700)', bg: 'var(--violet-50)', bd: 'var(--violet-300)' },
  red: { fg: 'var(--red-700)', bg: 'var(--red-50)', bd: 'var(--red-300)' },
};

/**
 * Permission-profile tag (docs / prepare / dev / check / merge). Each profile
 * owns a tone so the launch safety level reads at a glance.
 */
export function ProfileTag({ profile = '', size = 'md', style }) {
  const tone = PROFILES[profile] != null ? PROFILES[profile] : 'neutral';
  const t = TONES[tone] || TONES.neutral;
  const label = profile || 'no profile';
  const sizes = { sm: { h: 18, fs: 'var(--text-2xs)' }, md: { h: 21, fs: 'var(--text-xs)' } };
  const s = sizes[size] || sizes.md;
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', height: s.h, padding: '0 8px',
        fontFamily: 'var(--font-mono)', fontSize: s.fs, fontWeight: 'var(--weight-semibold)',
        color: profile ? t.fg : 'var(--text-subtle)', background: profile ? t.bg : 'transparent',
        border: `1px dashed ${profile ? 'transparent' : 'var(--border-default)'}`,
        borderStyle: profile ? 'solid' : 'dashed', borderColor: profile ? t.bd : 'var(--border-default)',
        borderRadius: 'var(--radius-xs)', whiteSpace: 'nowrap', ...style,
      }}
    >
      {label}
    </span>
  );
}

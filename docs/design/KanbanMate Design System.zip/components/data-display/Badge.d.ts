import * as React from 'react';

export interface BadgeProps {
  tone?: 'neutral' | 'accent' | 'red' | 'amber' | 'blue' | 'violet';
  variant?: 'soft' | 'solid';
  size?: 'sm' | 'md';
  /** Leading status dot. */
  dot?: boolean;
  mono?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Neutral status/label pill primitive. Prefer HealthPill/ColumnClassChip for semantic states. */
export function Badge(props: BadgeProps): JSX.Element;

import React from 'react';

const HEALTH = {
  INACTIVE: { fg: 'var(--health-inactive-fg)', bg: 'var(--health-inactive-bg)', bd: 'var(--health-inactive-bd)', github: 'Inactive' },
  BLOCKED: { fg: 'var(--health-blocked-fg)', bg: 'var(--health-blocked-bg)', bd: 'var(--health-blocked-bd)', github: 'Off track' },
  WAITING: { fg: 'var(--health-waiting-fg)', bg: 'var(--health-waiting-bg)', bd: 'var(--health-waiting-bd)', github: 'At risk' },
  ACTIVE: { fg: 'var(--health-active-fg)', bg: 'var(--health-active-bg)', bd: 'var(--health-active-bd)', github: 'On track' },
  COMPLETE: { fg: 'var(--health-complete-fg)', bg: 'var(--health-complete-bg)', bd: 'var(--health-complete-bd)', github: 'Complete' },
};

/**
 * The KanbanMate dashboard health pill — its single most important status
 * signal. `status` is one of the five health states; `pulse` animates the dot
 * for the live ACTIVE state.
 */
export function HealthPill({ status = 'ACTIVE', size = 'md', pulse = false, showGithub = false, style }) {
  const h = HEALTH[status] || HEALTH.INACTIVE;
  const sizes = { sm: { h: 20, px: 8, fs: 'var(--text-2xs)', dot: 6 }, md: { h: 24, px: 10, fs: 'var(--text-xs)', dot: 7 }, lg: { h: 30, px: 13, fs: 'var(--text-sm)', dot: 8 } };
  const s = sizes[size] || sizes.md;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
      <span
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, height: s.h, padding: `0 ${s.px}px`,
          fontFamily: 'var(--font-mono)', fontSize: s.fs, fontWeight: 'var(--weight-semibold)',
          letterSpacing: '0.04em', color: h.fg, background: h.bg,
          border: `1px solid ${h.bd}`, borderRadius: 'var(--radius-pill)', whiteSpace: 'nowrap', ...style,
        }}
      >
        <span style={{ position: 'relative', width: s.dot, height: s.dot, flex: 'none' }}>
          <span style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: h.fg }} />
          {pulse && (
            <span style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: h.fg, animation: 'km-ping 1.6s var(--ease-out) infinite' }}>
              <style>{'@keyframes km-ping{0%{transform:scale(1);opacity:.7}70%,100%{transform:scale(2.6);opacity:0}}'}</style>
            </span>
          )}
        </span>
        {status}
      </span>
      {showGithub && (
        <span style={{ fontFamily: 'var(--font-sans)', fontSize: 'var(--text-xs)', color: 'var(--text-subtle)' }}>
          GitHub: {h.github}
        </span>
      )}
    </span>
  );
}

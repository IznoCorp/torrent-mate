import React from 'react';

const CLASSES = {
  agent: { fg: 'var(--col-agent-fg)', bg: 'var(--col-agent-bg)', bd: 'var(--col-agent-bd)', solid: 'var(--col-agent-solid)' },
  reactive: { fg: 'var(--col-reactive-fg)', bg: 'var(--col-reactive-bg)', bd: 'var(--col-reactive-bd)', solid: 'var(--col-reactive-solid)' },
  inert: { fg: 'var(--col-inert-fg)', bg: 'var(--col-inert-bg)', bd: 'var(--col-inert-bd)', solid: 'var(--col-inert-solid)' },
};

/**
 * Marks a board column's class — agent (launches an agent), reactive (mechanical
 * side-effect), or inert (human gate / terminal). Square-dot + mono label.
 */
export function ColumnClassChip({ columnClass = 'inert', size = 'md', style }) {
  const c = CLASSES[columnClass] || CLASSES.inert;
  const sizes = { sm: { h: 18, px: 7, fs: 'var(--text-2xs)' }, md: { h: 22, px: 9, fs: 'var(--text-xs)' } };
  const s = sizes[size] || sizes.md;
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6, height: s.h, padding: `0 ${s.px}px`,
        fontFamily: 'var(--font-mono)', fontSize: s.fs, fontWeight: 'var(--weight-semibold)',
        color: c.fg, background: c.bg, border: `1px solid ${c.bd}`,
        borderRadius: 'var(--radius-xs)', whiteSpace: 'nowrap', ...style,
      }}
    >
      <span style={{ width: 7, height: 7, borderRadius: 2, background: c.solid, flex: 'none' }} />
      {columnClass}
    </span>
  );
}

import React from 'react';

/**
 * Inline monospace chip for a literal identifier the daemon reads — a column key
 * (`InProgress`), a placeholder token (`{{branch}}`), a path. `copyable` adds a
 * click-to-copy affordance. This is how the UI signals "exact string".
 */
export function KeyChip({ children, tone = 'neutral', copyable = false, size = 'md', style }) {
  const [copied, setCopied] = React.useState(false);
  const tones = {
    neutral: { fg: 'var(--text-body)', bg: 'var(--surface-sunken)', bd: 'var(--border-subtle)' },
    accent: { fg: 'var(--accent-text)', bg: 'var(--accent-weak)', bd: 'var(--accent-weak-border)' },
    token: { fg: 'var(--col-agent-fg)', bg: 'var(--col-agent-bg)', bd: 'var(--col-agent-bd)' },
  };
  const t = tones[tone] || tones.neutral;
  const sizes = { sm: { h: 18, fs: 'var(--text-2xs)' }, md: { h: 21, fs: 'var(--text-xs)' } };
  const s = sizes[size] || sizes.md;
  const copy = () => {
    if (!copyable) return;
    try { navigator.clipboard.writeText(String(children)); } catch (e) { /* noop */ }
    setCopied(true); setTimeout(() => setCopied(false), 1100);
  };
  return (
    <span
      onClick={copy}
      title={copyable ? 'Copy' : undefined}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 5, height: s.h, padding: '0 7px',
        fontFamily: 'var(--font-mono)', fontSize: s.fs, fontWeight: 'var(--weight-medium)',
        color: t.fg, background: t.bg, border: `1px solid ${t.bd}`, borderRadius: 'var(--radius-xs)',
        whiteSpace: 'nowrap', cursor: copyable ? 'pointer' : 'default', ...style,
      }}
    >
      {children}
      {copyable && <span style={{ fontSize: 10, opacity: 0.6 }}>{copied ? '✓' : '⧉'}</span>}
    </span>
  );
}

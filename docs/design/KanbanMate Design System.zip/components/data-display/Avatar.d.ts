import * as React from 'react';

export interface AvatarProps {
  label?: string;
  /** `agent` = tinted violet square with mono initials; `human` = rounded. */
  kind?: 'agent' | 'human';
  src?: string | null;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  style?: React.CSSProperties;
}

/** Identity avatar for agents (square) and humans (round). */
export function Avatar(props: AvatarProps): JSX.Element;

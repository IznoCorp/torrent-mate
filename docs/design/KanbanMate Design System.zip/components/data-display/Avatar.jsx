import React from 'react';

/**
 * Small identity avatar — an agent (mono initials on a tinted square, the agent
 * violet) or a human (GitHub-style rounded). Used on ticket cards and agent rows.
 */
export function Avatar({ label = '?', kind = 'human', src = null, size = 'md', style }) {
  const sizes = { xs: 18, sm: 22, md: 28, lg: 36 };
  const d = sizes[size] || sizes.md;
  const isAgent = kind === 'agent';
  const initials = String(label).trim().slice(0, 2).toUpperCase();
  return (
    <span
      title={label}
      style={{
        display: 'inline-grid', placeItems: 'center', width: d, height: d, flex: 'none',
        borderRadius: isAgent ? 'var(--radius-sm)' : '50%', overflow: 'hidden',
        background: isAgent ? 'var(--col-agent-bg)' : 'var(--surface-sunken)',
        border: `1px solid ${isAgent ? 'var(--col-agent-bd)' : 'var(--border-subtle)'}`,
        color: isAgent ? 'var(--col-agent-fg)' : 'var(--text-muted)',
        fontFamily: 'var(--font-mono)', fontSize: d <= 22 ? 9 : 11, fontWeight: 600, ...style,
      }}
    >
      {src ? <img src={src} alt={label} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : initials}
    </span>
  );
}

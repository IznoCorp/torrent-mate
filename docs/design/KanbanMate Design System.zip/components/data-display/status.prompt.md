**Status & label primitives** — Badge, HealthPill, ColumnClassChip, KeyChip, ProfileTag, Avatar.

```jsx
<HealthPill status="ACTIVE" pulse showGithub />
<ColumnClassChip columnClass="agent" />
<KeyChip tone="token" copyable>{'{{branch}}'}</KeyChip>
<ProfileTag profile="dev" />
<Avatar kind="agent" label="ticket-12" />
```

HealthPill is the headline status (five-state vocabulary). ColumnClassChip / ProfileTag encode board + launch semantics by colour. KeyChip is the mono "this is a literal string" marker. Badge is the neutral fallback primitive.

import React from 'react';

/**
 * Generic small status/label pill. For semantic tones use HealthPill /
 * ColumnClassChip / ProfileTag instead — this is the neutral primitive they and
 * everything else build on (counts, "default", "no profile", etc).
 */
export function Badge({ children, tone = 'neutral', variant = 'soft', size = 'md', dot = false, mono = false, style }) {
  const tones = {
    neutral: { fg: 'var(--text-muted)', bg: 'var(--surface-sunken)', bd: 'var(--border-subtle)', solid: 'var(--gray-500)' },
    accent: { fg: 'var(--accent-text)', bg: 'var(--accent-weak)', bd: 'var(--accent-weak-border)', solid: 'var(--accent)' },
    red: { fg: 'var(--red-700)', bg: 'var(--red-50)', bd: 'var(--red-300)', solid: 'var(--red-500)' },
    amber: { fg: 'var(--amber-700)', bg: 'var(--amber-50)', bd: 'var(--amber-300)', solid: 'var(--amber-500)' },
    blue: { fg: 'var(--blue-700)', bg: 'var(--blue-50)', bd: 'var(--blue-300)', solid: 'var(--blue-500)' },
    violet: { fg: 'var(--violet-700)', bg: 'var(--violet-50)', bd: 'var(--violet-300)', solid: 'var(--violet-500)' },
  };
  const t = tones[tone] || tones.neutral;
  const sizes = { sm: { h: 18, px: 7, fs: 'var(--text-2xs)' }, md: { h: 22, px: 9, fs: 'var(--text-xs)' } };
  const s = sizes[size] || sizes.md;
  const solid = variant === 'solid';
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 5, height: s.h, padding: `0 ${s.px}px`,
        fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)', fontSize: s.fs,
        fontWeight: 'var(--weight-semibold)', lineHeight: 1, whiteSpace: 'nowrap',
        color: solid ? 'var(--primary-foreground)' : t.fg, background: solid ? t.solid : t.bg,
        border: `1px solid ${solid ? 'transparent' : t.bd}`, borderRadius: 'var(--radius-sm)', ...style,
      }}
    >
      {dot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: solid ? '#fff' : t.solid }} />}
      {children}
    </span>
  );
}

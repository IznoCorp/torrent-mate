import * as React from 'react';

export interface ColumnClassChipProps {
  columnClass?: 'agent' | 'reactive' | 'inert';
  size?: 'sm' | 'md';
  style?: React.CSSProperties;
}

/** Marks a board column's behaviour class (agent / reactive / inert). */
export function ColumnClassChip(props: ColumnClassChipProps): JSX.Element;

import React from 'react';

/**
 * Generic surface container — the white panel with a 1px border that everything
 * sits in. `padding` and `header`/`footer` slots cover most config-panel needs.
 */
export function Card({ children, header = null, footer = null, padding = 'md', interactive = false, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const pads = { none: 0, sm: 'var(--space-5)', md: 'var(--space-7)', lg: 'var(--space-8)' };
  const pad = pads[padding] != null ? pads[padding] : pads.md;
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => interactive && setHover(true)}
      onMouseLeave={() => interactive && setHover(false)}
      style={{
        background: 'var(--card)', border: `1px solid ${hover ? 'var(--border)' : 'var(--border)'}`,
        borderRadius: 'var(--radius-xl)', boxShadow: hover ? 'var(--shadow-sm)' : 'var(--shadow-xs)',
        color: 'var(--card-foreground)',
        cursor: interactive ? 'pointer' : 'default', overflow: 'hidden',
        transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)',
        ...style,
      }}
    >
      {header && <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-md)', letterSpacing: 'var(--tracking-tight)', color: 'var(--foreground)' }}>{header}</div>}
      <div style={{ padding: pad }}>{children}</div>
      {footer && <div style={{ padding: '14px 20px', borderTop: '1px solid var(--border)', background: 'var(--muted)' }}>{footer}</div>}
    </div>
  );
}

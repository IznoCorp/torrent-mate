**Button** — the standard KanbanMate action control; one `primary` (signal-green) per view, `secondary`/`ghost` for the rest, `danger` only for destructive actions.

```jsx
<Button variant="primary" onClick={save}>Save config</Button>
<Button variant="secondary" leadingIcon={<PlusIcon/>}>Add column</Button>
<Button variant="ghost" size="sm">Cancel</Button>
<Button variant="danger" loading>Deleting…</Button>
```

Variants: `primary · secondary · ghost · danger`. Sizes: `sm · md · lg`. Props: `loading`, `fullWidth`, `leadingIcon`, `trailingIcon`, plus native button attrs. Focus shows a 3px accent ring; press deepens the surface (no scale).

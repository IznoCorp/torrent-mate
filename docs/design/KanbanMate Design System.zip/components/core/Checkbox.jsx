import React from 'react';

/** Checkbox with the brand check colour. For multi-select / opt-in rows. */
export function Checkbox({ checked = false, indeterminate = false, disabled = false, label = null, onChange, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const on = checked || indeterminate;
  const box = (
    <button
      type="button"
      role="checkbox"
      aria-checked={indeterminate ? 'mixed' : checked}
      disabled={disabled}
      onClick={() => !disabled && onChange && onChange(!checked)}
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      style={{
        width: 17, height: 17, flex: 'none', padding: 0, display: 'grid', placeItems: 'center',
        borderRadius: 'var(--radius-sm)', cursor: disabled ? 'not-allowed' : 'pointer',
        background: on ? 'var(--primary)' : 'var(--card)',
        border: `1px solid ${on ? 'var(--primary)' : 'var(--input)'}`,
        boxShadow: focus ? 'var(--shadow-focus)' : 'var(--shadow-2xs)', outline: 'none', opacity: disabled ? 0.5 : 1,
        transition: 'background var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)',
      }}
      {...rest}
    >
      {indeterminate ? (
        <span style={{ width: 8, height: 2, background: 'var(--primary-foreground)', borderRadius: 1 }} />
      ) : checked ? (
        <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2L4.8 8.5L9.5 3.5" stroke="var(--primary-foreground)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
      ) : null}
    </button>
  );
  if (!label) return box;
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 'var(--space-4)', cursor: disabled ? 'not-allowed' : 'pointer', fontSize: 'var(--text-sm)', color: 'var(--foreground)', ...style }}>
      {box}{label}
    </label>
  );
}

import React from 'react';

/**
 * Multi-line text for prompts and scripts. Mono by default (prompts carry slash
 * commands + {{tokens}}). Auto-shows the error border for finding-linked fields.
 */
export function Textarea({
  value, defaultValue, placeholder, rows = 3, mono = true, invalid = false, disabled = false, onChange, style, ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const border = invalid ? 'var(--destructive)' : focus ? 'var(--ring)' : 'var(--input)';
  return (
    <textarea
      value={value}
      defaultValue={defaultValue}
      placeholder={placeholder}
      rows={rows}
      disabled={disabled}
      onChange={onChange}
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      style={{
        width: '100%', padding: 'var(--space-5)', resize: 'vertical',
        fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)', fontSize: 'var(--text-sm)',
        lineHeight: 1.6, color: 'var(--foreground)',
        background: disabled ? 'var(--muted)' : 'var(--card)',
        border: `1px solid ${border}`, borderRadius: 'var(--radius-md)',
        boxShadow: focus ? 'var(--shadow-focus)' : 'var(--shadow-2xs)', outline: 'none',
        transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)',
        ...style,
      }}
      {...rest}
    />
  );
}

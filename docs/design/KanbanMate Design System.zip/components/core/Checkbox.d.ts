import * as React from 'react';

export interface CheckboxProps {
  checked?: boolean;
  indeterminate?: boolean;
  disabled?: boolean;
  label?: React.ReactNode;
  onChange?: (next: boolean) => void;
  style?: React.CSSProperties;
}

/** Checkbox with optional inline label; supports an indeterminate state. */
export function Checkbox(props: CheckboxProps): JSX.Element;

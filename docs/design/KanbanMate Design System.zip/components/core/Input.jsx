import React from 'react';

/**
 * Text input. Mono variant for literal identifiers the daemon reads (column
 * keys, permission_mode, placeholder tokens) so the field reads like the config
 * file. `invalid` paints the error border used by validation findings.
 */
export function Input({
  value,
  defaultValue,
  placeholder,
  type = 'text',
  mono = false,
  size = 'md',
  invalid = false,
  disabled = false,
  leadingAddon = null,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = { sm: { h: 32, fs: 'var(--text-sm)' }, md: { h: 36, fs: 'var(--text-sm)' }, lg: { h: 40, fs: 'var(--text-base)' } };
  const s = sizes[size] || sizes.md;
  const border = invalid ? 'var(--destructive)' : focus ? 'var(--ring)' : 'var(--input)';

  const field = (
    <input
      type={type}
      value={value}
      defaultValue={defaultValue}
      placeholder={placeholder}
      disabled={disabled}
      onChange={onChange}
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      style={{
        flex: 1, minWidth: 0, height: s.h, padding: `0 ${leadingAddon ? '8px' : 'var(--space-5)'}`,
        fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)', fontSize: s.fs,
        color: 'var(--foreground)', background: 'transparent', border: 'none', outline: 'none', width: '100%',
      }}
      {...rest}
    />
  );

  return (
    <div
      style={{
        display: 'flex', alignItems: 'center',
        background: disabled ? 'var(--muted)' : 'var(--card)',
        border: `1px solid ${border}`, borderRadius: 'var(--radius-md)',
        boxShadow: focus ? (invalid ? '0 0 0 3px color-mix(in oklch, var(--destructive) 28%, transparent)' : 'var(--shadow-focus)') : 'var(--shadow-2xs)',
        opacity: disabled ? 0.6 : 1,
        transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)',
        ...style,
      }}
    >
      {leadingAddon && (
        <span style={{ paddingLeft: 'var(--space-5)', color: 'var(--muted-foreground)', fontFamily: 'var(--font-mono)', fontSize: s.fs, whiteSpace: 'nowrap' }}>
          {leadingAddon}
        </span>
      )}
      {field}
    </div>
  );
}

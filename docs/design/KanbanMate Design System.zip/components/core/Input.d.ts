import * as React from 'react';

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'style'> {
  size?: 'sm' | 'md' | 'lg';
  /** Set monospace for literal identifiers (keys, modes, tokens). */
  mono?: boolean;
  /** Error state — paints the red border used by validation findings. */
  invalid?: boolean;
  /** Inline mono prefix shown inside the field (e.g. a path or "from:"). */
  leadingAddon?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Single-line text input; use `mono` for any string the daemon parses literally. */
export function Input(props: InputProps): JSX.Element;

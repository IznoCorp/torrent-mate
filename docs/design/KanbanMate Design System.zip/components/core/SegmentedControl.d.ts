import * as React from 'react';

export type SegmentOption = string | { value: string; label: React.ReactNode };

export interface SegmentedControlProps {
  options: SegmentOption[];
  value: string;
  onChange?: (value: string) => void;
  size?: 'sm' | 'md';
  mono?: boolean;
  fullWidth?: boolean;
  style?: React.CSSProperties;
}

/** Inline single-choice picker (e.g. column_class reactive/inert, view toggles). */
export function SegmentedControl(props: SegmentedControlProps): JSX.Element;

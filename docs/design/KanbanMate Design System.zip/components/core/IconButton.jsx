import React from 'react';

/**
 * Square icon-only button. Same interaction language as Button but for a single
 * glyph — board toolbar actions, row controls (drag handle, delete, expand).
 * Always pass `aria-label`.
 */
export function IconButton({
  children,
  variant = 'ghost',
  size = 'md',
  disabled = false,
  active = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const [focus, setFocus] = React.useState(false);

  const dims = { sm: 26, md: 32, lg: 38 };
  const d = dims[size] || dims.md;

  const palettes = {
    ghost: { bg: 'transparent', bgHover: 'var(--accent)', fg: 'var(--muted-foreground)', fgHover: 'var(--accent-foreground)', bd: 'transparent' },
    secondary: { bg: 'var(--card)', bgHover: 'var(--accent)', fg: 'var(--foreground)', fgHover: 'var(--accent-foreground)', bd: 'var(--border)' },
    danger: { bg: 'transparent', bgHover: 'var(--health-blocked-bg)', fg: 'var(--muted-foreground)', fgHover: 'var(--destructive)', bd: 'transparent' },
  };
  const p = palettes[variant] || palettes.ghost;
  const isActive = active || press;

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      style={{
        display: 'inline-grid', placeItems: 'center', width: d, height: d, flex: 'none',
        color: (hover || isActive) ? p.fgHover : p.fg,
        background: isActive ? 'var(--accent)' : hover ? p.bgHover : p.bg,
        border: `1px solid ${p.bd}`, borderRadius: 'var(--radius-md)',
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1,
        boxShadow: focus ? 'var(--shadow-focus)' : 'none', outline: 'none',
        transition: 'background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard)',
        ...style,
      }}
      {...rest}
    >
      {children}
    </button>
  );
}

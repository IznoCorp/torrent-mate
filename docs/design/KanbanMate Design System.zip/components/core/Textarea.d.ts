import * as React from 'react';

export interface TextareaProps extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'style'> {
  mono?: boolean;
  invalid?: boolean;
  style?: React.CSSProperties;
}

/** Multi-line input for prompts/scripts; monospace by default. */
export function Textarea(props: TextareaProps): JSX.Element;

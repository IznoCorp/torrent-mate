import React from 'react';

/**
 * KanbanMate primary control. Variants map to intent: `primary` (signal-green,
 * the one committing action per view), `secondary` (bordered neutral), `ghost`
 * (text-only), `danger` (destructive — e.g. delete a column/transition).
 */
export function Button({
  children,
  variant = 'secondary',
  size = 'md',
  type = 'button',
  disabled = false,
  loading = false,
  fullWidth = false,
  leadingIcon = null,
  trailingIcon = null,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const [focus, setFocus] = React.useState(false);

  const sizes = {
    sm: { h: 32, px: 'var(--space-5)', fs: 'var(--text-sm)', gap: 6 },
    md: { h: 36, px: 'var(--space-6)', fs: 'var(--text-sm)', gap: 8 },
    lg: { h: 40, px: 'var(--space-7)', fs: 'var(--text-base)', gap: 8 },
  };
  const s = sizes[size] || sizes.md;

  /* shadcn variants: default=primary, outline=secondary, ghost, destructive=danger */
  const palettes = {
    primary: {
      bg: 'var(--primary)', bgHover: 'color-mix(in oklch, var(--primary) 90%, transparent)',
      bgActive: 'color-mix(in oklch, var(--primary) 82%, black)',
      fg: 'var(--primary-foreground)', bd: 'transparent', shadow: 'var(--shadow-xs)',
    },
    secondary: {
      bg: 'var(--card)', bgHover: 'var(--accent)', bgActive: 'var(--accent)',
      fg: 'var(--accent-foreground)', bd: 'var(--border)', shadow: 'var(--shadow-xs)',
    },
    ghost: {
      bg: 'transparent', bgHover: 'var(--accent)', bgActive: 'var(--accent)',
      fg: 'var(--foreground)', bd: 'transparent', shadow: 'none',
    },
    danger: {
      bg: 'var(--destructive)', bgHover: 'color-mix(in oklch, var(--destructive) 90%, transparent)',
      bgActive: 'color-mix(in oklch, var(--destructive) 82%, black)',
      fg: 'var(--destructive-foreground)', bd: 'transparent', shadow: 'var(--shadow-xs)',
    },
  };
  const p = palettes[variant] || palettes.secondary;
  const isDisabled = disabled || loading;
  const bg = active ? p.bgActive : hover ? p.bgHover : p.bg;

  return (
    <button
      type={type}
      disabled={isDisabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: s.gap,
        height: s.h, padding: `0 ${s.px}`, width: fullWidth ? '100%' : 'auto',
        fontFamily: 'var(--font-sans)', fontSize: s.fs, fontWeight: 'var(--weight-medium)',
        lineHeight: 1, whiteSpace: 'nowrap',
        color: isDisabled ? 'var(--muted-foreground)' : p.fg, background: isDisabled ? 'var(--muted)' : bg,
        border: `1px solid ${isDisabled ? 'var(--border)' : p.bd}`,
        borderRadius: 'var(--radius-md)', cursor: isDisabled ? 'not-allowed' : 'pointer',
        opacity: isDisabled ? 0.5 : 1,
        boxShadow: focus && !isDisabled ? 'var(--shadow-focus)' : (isDisabled ? 'none' : p.shadow),
        transition: 'background var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)',
        outline: 'none', ...style,
      }}
      {...rest}
    >
      {loading && <Spinner />}
      {!loading && leadingIcon}
      {children}
      {!loading && trailingIcon}
    </button>
  );
}

function Spinner() {
  return (
    <span
      style={{
        width: 13, height: 13, borderRadius: '50%',
        border: '2px solid currentColor', borderTopColor: 'transparent',
        display: 'inline-block', animation: 'km-spin 0.6s linear infinite', opacity: 0.9,
      }}
    >
      <style>{'@keyframes km-spin{to{transform:rotate(360deg)}}'}</style>
    </span>
  );
}

import * as React from 'react';

export interface IconButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'style'> {
  variant?: 'ghost' | 'secondary' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  /** Sticky pressed look (e.g. an active toggle in a toolbar). */
  active?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties;
  /** A single icon node (e.g. 16–18px Lucide). Always set aria-label. */
  children?: React.ReactNode;
}

/** Square icon-only button for toolbars and row controls. Requires aria-label. */
export function IconButton(props: IconButtonProps): JSX.Element;

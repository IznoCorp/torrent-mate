import * as React from 'react';

export interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'style'> {
  /** Visual intent. `primary` = the single committing action per view. */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  /** Shows a spinner and disables the button. */
  loading?: boolean;
  fullWidth?: boolean;
  /** Icon node placed before the label (e.g. a 16px Lucide icon). */
  leadingIcon?: React.ReactNode;
  trailingIcon?: React.ReactNode;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

/**
 * KanbanMate button. One primary per view; secondary/ghost for everything else;
 * danger only for destructive actions.
 *
 * @startingPoint section="Core" subtitle="Primary / secondary / ghost / danger button" viewport="700x150"
 */
export function Button(props: ButtonProps): JSX.Element;

import React from 'react';

/** On/off switch. Green when on (the brand "go" colour). For boolean config
 * flags like interactive-only / unattended. */
export function Switch({ checked = false, disabled = false, onChange, size = 'md', style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const dims = { sm: { w: 30, h: 17, k: 13 }, md: { w: 38, h: 22, k: 17 } };
  const d = dims[size] || dims.md;
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => !disabled && onChange && onChange(!checked)}
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      style={{
        position: 'relative', width: d.w, height: d.h, flex: 'none', padding: 0, border: 'none',
        borderRadius: 'var(--radius-pill)', cursor: disabled ? 'not-allowed' : 'pointer',
        background: checked ? 'var(--primary)' : 'var(--input)', opacity: disabled ? 0.5 : 1,
        boxShadow: focus ? 'var(--shadow-focus)' : 'var(--shadow-2xs)', outline: 'none',
        transition: 'background var(--dur-base) var(--ease-standard)', ...style,
      }}
      {...rest}
    >
      <span
        style={{
          position: 'absolute', top: (d.h - d.k) / 2, left: checked ? d.w - d.k - (d.h - d.k) / 2 : (d.h - d.k) / 2,
          width: d.k, height: d.k, borderRadius: '50%', background: 'var(--card)',
          boxShadow: 'var(--shadow-sm)', transition: 'left var(--dur-base) var(--ease-out)',
        }}
      />
    </button>
  );
}

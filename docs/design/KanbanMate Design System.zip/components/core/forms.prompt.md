**Form controls** — Button, IconButton, Input, Select, Textarea, Switch, Checkbox, SegmentedControl.

```jsx
<Input mono placeholder="InProgress" leadingAddon="key:" />
<Select options={['docs','prepare','dev','check']} value="dev" />
<SegmentedControl options={['reactive','inert']} value="inert" mono />
<Switch checked onChange={setOn} />
```

All controls share the focus ring, error (`invalid`) state, and size scale. Use `mono` on any field that holds a literal identifier the daemon reads.

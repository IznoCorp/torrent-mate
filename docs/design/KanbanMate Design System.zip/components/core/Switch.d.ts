import * as React from 'react';

export interface SwitchProps {
  checked?: boolean;
  disabled?: boolean;
  size?: 'sm' | 'md';
  onChange?: (next: boolean) => void;
  style?: React.CSSProperties;
}

/** Boolean toggle; green when on. */
export function Switch(props: SwitchProps): JSX.Element;

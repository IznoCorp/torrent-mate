import * as React from 'react';

export type SelectOption = string | { value: string; label: string };

export interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'size' | 'style'> {
  options?: SelectOption[];
  size?: 'sm' | 'md' | 'lg';
  /** Monospace options (default true — config enums are literal). */
  mono?: boolean;
  invalid?: boolean;
  style?: React.CSSProperties;
}

/** Styled native select for enum config fields (profile, permission_mode, …). */
export function Select(props: SelectProps): JSX.Element;

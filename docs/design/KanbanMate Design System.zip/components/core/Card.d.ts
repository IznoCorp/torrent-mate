import * as React from 'react';

export interface CardProps {
  header?: React.ReactNode;
  footer?: React.ReactNode;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  /** Hover affordance for clickable cards. */
  interactive?: boolean;
  onClick?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Surface container with optional header/footer slots. */
export function Card(props: CardProps): JSX.Element;

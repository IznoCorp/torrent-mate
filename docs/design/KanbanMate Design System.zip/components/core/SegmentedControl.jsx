import React from 'react';

/**
 * Segmented control — the inline single-choice picker used across the config UI
 * (e.g. column_class reactive/inert, a small view toggle). Mono labels by
 * default since the options are usually literal config values.
 */
export function SegmentedControl({ options = [], value, onChange, size = 'md', mono = false, fullWidth = false, style }) {
  const sizes = { sm: { h: 26, fs: 'var(--text-xs)', px: 10 }, md: { h: 32, fs: 'var(--text-sm)', px: 12 } };
  const s = sizes[size] || sizes.md;
  return (
    <div
      role="tablist"
      style={{
        display: 'inline-flex', width: fullWidth ? '100%' : 'auto', padding: 3, gap: 2,
        background: 'var(--muted)', border: '1px solid var(--border)',
        borderRadius: 'var(--radius-lg)', ...style,
      }}
    >
      {options.map((o) => {
        const opt = typeof o === 'string' ? { value: o, label: o } : o;
        const selected = opt.value === value;
        return (
          <button
            key={opt.value}
            type="button"
            role="tab"
            aria-selected={selected}
            onClick={() => onChange && onChange(opt.value)}
            style={{
              flex: fullWidth ? 1 : 'none', height: s.h, padding: `0 ${s.px}px`,
              fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)', fontSize: s.fs,
              fontWeight: 'var(--weight-medium)', whiteSpace: 'nowrap',
              color: selected ? 'var(--foreground)' : 'var(--muted-foreground)',
              background: selected ? 'var(--card)' : 'transparent',
              border: `1px solid ${selected ? 'var(--border)' : 'transparent'}`,
              borderRadius: 'var(--radius-sm)', cursor: 'pointer',
              boxShadow: selected ? 'var(--shadow-xs)' : 'none',
              transition: 'background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard)',
            }}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

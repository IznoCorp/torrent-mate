import React from 'react';

/**
 * Native select styled to KanbanMate. Used for enum config fields — profile,
 * permission_mode, advance directive, column_class. Mono by default since the
 * options are literal values.
 */
export function Select({
  value,
  defaultValue,
  options = [],
  size = 'md',
  mono = true,
  invalid = false,
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = { sm: { h: 32, fs: 'var(--text-sm)' }, md: { h: 36, fs: 'var(--text-sm)' }, lg: { h: 40, fs: 'var(--text-base)' } };
  const s = sizes[size] || sizes.md;
  const border = invalid ? 'var(--destructive)' : focus ? 'var(--ring)' : 'var(--input)';

  return (
    <div style={{ position: 'relative', display: 'inline-flex', ...style }}>
      <select
        value={value}
        defaultValue={defaultValue}
        disabled={disabled}
        onChange={onChange}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          appearance: 'none', WebkitAppearance: 'none',
          height: s.h, padding: '0 30px 0 var(--space-5)', width: '100%',
          fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)', fontSize: s.fs,
          color: 'var(--foreground)',
          background: disabled ? 'var(--muted)' : 'var(--card)',
          border: `1px solid ${border}`, borderRadius: 'var(--radius-md)',
          boxShadow: focus ? 'var(--shadow-focus)' : 'var(--shadow-2xs)',
          cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.6 : 1, outline: 'none',
          transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)',
        }}
        {...rest}
      >
        {options.map((o) => {
          const opt = typeof o === 'string' ? { value: o, label: o } : o;
          return <option key={opt.value} value={opt.value}>{opt.label}</option>;
        })}
      </select>
      <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: 'var(--muted-foreground)', fontSize: 11 }}>▾</span>
    </div>
  );
}
